require('dotenv').config();

const fs = require('fs');
const path = require('path');
const CLIENT_ID = process.env.CLIENT_ID;
const CLIENT_SECRET = process.env.CLIENT_SECRET;

if (!CLIENT_ID || !CLIENT_SECRET) {
  console.warn('Warning: CLIENT_ID or CLIENT_SECRET not set in environment.');
}

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const { initializeDatabase } = require('./src/db');
const authRoutes = require('./src/routes/auth');
const paymentsRoutes = require('./src/routes/payments');
const adsRoutes = require('./src/routes/ads');
const callsRoutes = require('./src/routes/calls');
const enrollmentRoutes = require('./src/routes/enrollments');
const davidRoutes = require('./src/routes/david');

const app = express();
const PORT = Number(process.env.PORT || 3000);

app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'],
      fontSrc: ["'self'", 'https://fonts.gstatic.com'],
      imgSrc: ["'self'", 'data:', 'blob:', 'https:'],
      connectSrc: ["'self'", 'http://127.0.0.1:3000', 'https:'],
      frameAncestors: ["'self'"],
      objectSrc: ["'none'"]
    }
  }
}));
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '1mb' }));
app.use(express.static(__dirname));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'website.html'));
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Nivora backend is running.' });
});

app.get('/download/nivora-desktop.zip', (req, res) => {
  const downloadPath = path.join(__dirname, 'downloads', 'nivora-desktop.zip');

  if (!fs.existsSync(downloadPath)) {
    return res.status(404).json({
      status: 'error',
      message: 'Desktop bundle is not available yet. Please generate the download package.'
    });
  }

  res.setHeader('Content-Type', 'application/zip');
  res.setHeader('Content-Disposition', 'attachment; filename="nivora-desktop.zip"');
  return res.sendFile(downloadPath);
});

app.use('/api/auth', authRoutes);
app.use('/api/payments', paymentsRoutes);
app.use('/api/ads', adsRoutes);
app.use('/api/calls', callsRoutes);
app.use('/api/enrollments', enrollmentRoutes);
app.use('/api/david', davidRoutes);

if (require.main === module) {
  initializeDatabase()
    .then(() => {
      app.listen(PORT, () => {
        console.log(`Nivora backend listening on port ${PORT}`);
      });
    })
    .catch((error) => {
      console.error('Failed to initialize database:', error);
      process.exit(1);
    });
}

module.exports = app;
