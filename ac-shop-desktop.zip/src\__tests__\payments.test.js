const request = require('supertest');
const app = require('../../server');
const { initializeDatabase, run } = require('../db');
const { signAccessToken } = require('../utils/jwt');
const axios = require('axios');

jest.mock('axios');

describe('Payouts API (mocked)', () => {
  beforeAll(async () => {
    await initializeDatabase();
    process.env.AIRTM_API_KEY = 'testkey';
    process.env.AIRTM_API_BASE = 'https://airtm.test';
    process.env.AIRTM_PAYOUT_PATH = '/v1/payouts';
    await run("INSERT OR IGNORE INTO users (email, password_hash, email_verified) VALUES (?, ?, 1)", ['tester@airtm.com', 'hash']);
    await run("INSERT OR IGNORE INTO payout_consents (user_email, provider, account_reference, consent_granted, consented_at) VALUES (?,?,?,?,?)", ['tester@airtm.com', 'airtm', 'igbokwefranksaviour@gmail.com', 1, new Date().toISOString()]);
  });

  test('Airtm payout uses Airtm API', async () => {
    axios.mockResolvedValue({ data: { success: true, id: 'airtm-test-1' } });

    const token = signAccessToken({ email: 'tester@airtm.com' });
    const res = await request(app)
      .post('/api/payments/payouts')
      .set('Authorization', `Bearer ${token}`)
      .send({ provider: 'airtm', amount: 20 });

    expect(res.status).toBe(200);
    expect(res.body.message).toMatch(/Airtm payout submitted successfully/);
    expect(axios).toHaveBeenCalledWith(expect.objectContaining({
      method: 'post',
      url: 'https://airtm.test/v1/payouts',
      headers: expect.objectContaining({ Authorization: 'Bearer testkey' }),
      data: {
        receiver: 'igbokwefranksaviour@gmail.com',
        amount: '20.00',
        currency: 'USD',
        note: 'NovaLearn lesson payout'
      }
    }));
  });

  test('PayPal payout flow (mocked)', async () => {
    axios.mockImplementation(({ url }) => {
      if (url && url.includes('/v1/oauth2/token')) {
        return Promise.resolve({ data: { access_token: 'tok' } });
      }
      if (url && url.includes('/v1/payments/payouts')) {
        return Promise.resolve({ data: { batch_status: 'SUCCESS' } });
      }
      return Promise.resolve({ data: {} });
    });

    process.env.PAYPAL_CLIENT_ID = 'cid';
    process.env.PAYPAL_CLIENT_SECRET = 'csecret';

    const token = signAccessToken({ email: 'tester@airtm.com' });
    const res = await request(app)
      .post('/api/payments/payouts')
      .set('Authorization', `Bearer ${token}`)
      .send({ provider: 'paypal', amount: 25, accountReference: 'someone@example.com' });

    expect(res.status).toBe(200);
    expect(res.body.message).toMatch(/Payout request submitted successfully/);
    expect(axios).toHaveBeenCalledTimes(2);
    expect(axios.mock.calls[0][0]).toEqual(expect.objectContaining({ url: expect.stringContaining('/v1/oauth2/token') }));
    expect(axios.mock.calls[1][0]).toEqual(expect.objectContaining({
      url: expect.stringContaining('/v1/payments/payouts'),
      data: expect.objectContaining({
        items: [expect.objectContaining({ receiver: 'someone@example.com' })]
      })
    }));
  });

  test('Airtm failure returns provider error without pretending payout succeeded', async () => {
    axios.mockRejectedValueOnce(new Error('Airtm unavailable'));

    const token = signAccessToken({ email: 'tester@airtm.com' });
    const res = await request(app)
      .post('/api/payments/payouts')
      .set('Authorization', `Bearer ${token}`)
      .send({ provider: 'airtm', amount: 20 });

    expect(res.status).toBe(500);
    expect(res.body.message).toMatch(/Unable to create Airtm payout/);
  });
});
