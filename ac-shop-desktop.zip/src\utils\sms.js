const axios = require('axios');

async function sendSms({ to, message }) {
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const apiKeySid = process.env.TWILIO_API_KEY_SID;
  const apiKeySecret = process.env.TWILIO_API_KEY_SECRET;
  const authToken = process.env.TWILIO_AUTH_TOKEN;
  const from = process.env.TWILIO_FROM_NUMBER;

  if (!accountSid || !from || (!authToken && (!apiKeySid || !apiKeySecret))) {
    return { ok: false, reason: 'SMS provider is not configured' };
  }

  const credentials = apiKeySid && apiKeySecret
    ? { username: apiKeySid, password: apiKeySecret }
    : { username: accountSid, password: authToken };

  try {
    await axios.post(
      `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
      new URLSearchParams({ To: to, From: from, Body: message }).toString(),
      {
        auth: credentials,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
      }
    );
    return { ok: true };
  } catch (error) {
    console.error('SMS delivery error:', error.response?.data || error.message);
    return { ok: false, reason: 'SMS delivery failed' };
  }
}

module.exports = { sendSms };
