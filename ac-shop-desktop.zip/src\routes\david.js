const express = require('express');
const axios = require('axios');
const { get } = require('../db');
const { verifyAccessToken } = require('../utils/jwt');
const { sendEmail } = require('../utils/email');

const router = express.Router();
const CEO_EMAIL = 'igbokwefranksaviour@gmail.com';

function getAuthenticatedUser(req) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return null;
  try {
    return verifyAccessToken(header.slice(7).trim());
  } catch (error) {
    return null;
  }
}

async function requireSignedInUser(req, res, next) {
  const payload = getAuthenticatedUser(req);
  if (!payload) return res.status(401).json({ message: 'Sign in to use David.' });
  if (payload.role === 'ceo') {
    req.userEmail = payload.email;
    return next();
  }
  const email = payload.email;
  const user = await get('SELECT email FROM users WHERE email = ?', [email]);
  if (!user) return res.status(401).json({ message: 'Account not found.' });
  req.userEmail = email;
  return next();
}

const davidContext = `You are David, the Nivora AI agent. Nivora is a global learning platform with a maximum of 10,000 accounts. Completed features include email-link verification, password login, names, phone numbers with international dialing codes, country and postal-code collection, consented location capture, protected dashboards, live metrics, professor ads, enrollments, payments, and live calls. Current configuration may still require production credentials for OpenAI, SMS, payments, hosting, and domain DNS. Explain available features honestly, never claim an unavailable feature is live, and never request passwords, API keys, payment card numbers, or verification secrets. Help users understand Nivora and its workflows clearly.`;

router.use(requireSignedInUser);

router.post('/chat', async (req, res) => {
  const message = String(req.body?.message || '').trim();
  if (!message) return res.status(400).json({ message: 'Enter a message for David.' });
  if (!process.env.OPENAI_API_KEY) {
    return res.status(503).json({ message: 'David is still being configured. Please try again later.' });
  }

  try {
    const response = await axios.post(
      process.env.OPENAI_API_BASE || 'https://api.openai.com/v1/chat/completions',
      {
        model: process.env.OPENAI_MODEL || 'gpt-4o-mini',
        temperature: 0.3,
        messages: [
          { role: 'system', content: davidContext },
          { role: 'user', content: message }
        ]
      },
      { headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` }, timeout: 30000 }
    );

    const answer = response.data?.choices?.[0]?.message?.content?.trim();
    if (!answer) return res.status(502).json({ message: 'David could not produce a response.' });
    return res.json({ agent: 'David', answer });
  } catch (error) {
    console.error('David response error:', error.response?.data || error.message);
    return res.status(502).json({ message: 'David is temporarily unavailable. Please try again.' });
  }
});

router.post('/feedback', async (req, res) => {
  const type = ['up', 'down', 'message'].includes(req.body?.type) ? req.body.type : 'message';
  const userMessage = String(req.body?.userMessage || '');
  const davidResponse = String(req.body?.davidResponse || '');
  const result = await sendEmail({
    to: CEO_EMAIL,
    subject: `Nivora David feedback: ${type}`,
    text: `This message was sent by AI agent David.\n\nFeedback: ${type}\nUser: ${req.userEmail}\n\nUser message:\n${userMessage}\n\nDavid response:\n${davidResponse}`
  });
  if (!result.ok) return res.status(503).json({ message: 'Feedback email could not be sent.' });
  return res.json({ message: 'Feedback sent.' });
});

module.exports = router;
