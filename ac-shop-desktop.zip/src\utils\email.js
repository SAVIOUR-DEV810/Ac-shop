const nodemailer = require('nodemailer');

function createTransporter() {
  const host = process.env.SMTP_HOST;
  const port = Number(process.env.SMTP_PORT || 587);
  const user = process.env.SMTP_USER;
  const pass = String(process.env.SMTP_PASS || '').replace(/\s+/g, '');

  if (!host || !user || !pass) {
    return null;
  }

  return nodemailer.createTransport({
    host,
    port,
    secure: false,
    connectionTimeout: 10000,
    greetingTimeout: 10000,
    socketTimeout: 10000,
    auth: {
      user,
      pass
    }
  });
}

async function sendEmail({ to, subject, text }) {
  const transporter = createTransporter();
  if (!transporter) {
    return { ok: false, reason: 'SMTP not configured' };
  }

  const sender = process.env.SMTP_FROM || `Nivora <${process.env.SMTP_USER}>`;

  try {
    await transporter.sendMail({
      from: sender,
      to,
      subject,
      text
    });
  } catch (error) {
    console.error('Email delivery error:', error.message);
    return { ok: false, reason: 'Email delivery failed' };
  }

  return { ok: true };
}

async function sendVerificationLink({ to, link }) {
  return sendEmail({
    to,
    subject: 'Verify your Nivora account',
    text: `Verify your Nivora account by opening this link:\n\n${link}\n\nThis link expires in 30 minutes.`
  });
}

module.exports = { sendEmail, sendVerificationLink };
