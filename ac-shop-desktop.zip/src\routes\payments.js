const express = require('express');
const axios = require('axios');
const rateLimit = require('express-rate-limit');
const { get, run, all } = require('../db');
const { verifyAccessToken } = require('../utils/jwt');

const router = express.Router();

const paymentRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 40,
  standardHeaders: true,
  legacyHeaders: false
});

router.use(paymentRateLimiter);

function getAuthToken(req) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return null;
  return header.replace('Bearer ', '').trim();
}

router.post('/consent', async (req, res) => {
  const authToken = getAuthToken(req);
  if (!authToken) {
    return res.status(401).json({ message: 'Authorization is required.' });
  }

  try {
    const payload = verifyAccessToken(authToken);
    const { provider, accountReference } = req.body || {};

    if (!provider || !accountReference) {
      return res.status(400).json({ message: 'Provider and account reference are required.' });
    }

    const existing = await get(
      'SELECT * FROM payout_consents WHERE user_email = ? AND provider = ? ORDER BY created_at DESC LIMIT 1',
      [payload.email, provider]
    );

    if (existing) {
      await run(
        'UPDATE payout_consents SET consent_granted = 1, account_reference = ?, consented_at = ?, revoked_at = NULL WHERE id = ?',
        [String(accountReference), new Date().toISOString(), existing.id]
      );
    } else {
      await run(
        'INSERT INTO payout_consents (user_email, provider, account_reference, consent_granted, consented_at) VALUES (?, ?, ?, 1, ?)',
        [payload.email, provider, String(accountReference), new Date().toISOString()]
      );
    }

    return res.json({ message: 'Payout permission granted successfully.' });
  } catch (error) {
    console.error('Consent error:', error);
    return res.status(401).json({ message: 'Invalid or expired authentication token.' });
  }
});

router.post('/revoke-consent', async (req, res) => {
  const authToken = getAuthToken(req);
  if (!authToken) {
    return res.status(401).json({ message: 'Authorization is required.' });
  }

  try {
    const payload = verifyAccessToken(authToken);
    await run(
      'UPDATE payout_consents SET consent_granted = 0, revoked_at = ? WHERE user_email = ?',
      [new Date().toISOString(), payload.email]
    );

    return res.json({ message: 'Payout permission revoked.' });
  } catch (error) {
    console.error('Revoke consent error:', error);
    return res.status(401).json({ message: 'Invalid or expired authentication token.' });
  }
});

router.post('/payouts', async (req, res) => {
  const authToken = getAuthToken(req);
  if (!authToken) {
    return res.status(401).json({ message: 'Authorization is required.' });
  }

  try {
    const payload = verifyAccessToken(authToken);
    const { provider, amount, accountReference } = req.body || {};
    let resolvedAccountReference = String(accountReference || '').trim();

    if (!resolvedAccountReference) {
      if (String(provider).toLowerCase() === 'airtm') {
        resolvedAccountReference = String(process.env.AIRTM_RECEIVER_ACCOUNT || '').trim();
      } else if (String(provider).toLowerCase().includes('pay')) {
        resolvedAccountReference = String(process.env.PAYPAL_RECEIVER_EMAIL || '').trim();
      } else {
        // fallback to any configured receiver
        resolvedAccountReference = String(process.env.AIRTM_RECEIVER_ACCOUNT || process.env.PAYPAL_RECEIVER_EMAIL || '').trim();
      }
    }

    if (!provider || !amount || !resolvedAccountReference) {
      return res.status(400).json({ message: 'Provider, amount, and account reference are required.' });
    }

    const consent = await get(
      'SELECT * FROM payout_consents WHERE user_email = ? AND provider = ? AND consent_granted = 1 ORDER BY created_at DESC LIMIT 1',
      [payload.email, provider]
    );

    if (!consent) {
      return res.status(403).json({ message: 'You must approve payout access before requesting a payment.' });
    }

    const finalAmount = Number(amount);
    if (Number.isNaN(finalAmount) || finalAmount < 15) {
      return res.status(400).json({ message: 'Minimum payout is $15.' });
    }
    const providerLower = String(provider).toLowerCase();

    // Airtm-specific payout flow (requires AIRTM_API_KEY and AIRTM_API_BASE)
    if (providerLower === 'airtm') {
      const airtmKey = process.env.AIRTM_API_KEY;
      const airtmBase = process.env.AIRTM_API_BASE || 'https://api.airtm.com';
      const airtmPayoutPath = process.env.AIRTM_PAYOUT_PATH || '/v1/payouts';

      if (!airtmKey) {
        return res.status(503).json({ message: 'Airtm provider not configured. Add AIRTM_API_KEY to enable transfers.' });
      }

      try {
        const airtmResponse = await axios({
          method: 'post',
          url: `${airtmBase.replace(/\/+$/, '')}/${airtmPayoutPath.replace(/^\/+/, '')}`,
          data: {
            receiver: resolvedAccountReference,
            amount: String(finalAmount.toFixed(2)),
            currency: 'USD',
            note: 'NovaLearn lesson payout'
          },
          headers: {
            Authorization: `Bearer ${airtmKey}`,
            'Content-Type': 'application/json'
          }
        });

        await run(
          'INSERT INTO ads (user_email, professor_name, course_title, specialty, bio, inspiration, payout_amount, payment_method, payment_account, payment_name, payout_schedule) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [
            payload.email,
            'Stored payout record',
            'Payout',
            provider,
            'Payout created through provider API',
            'Secure payout consent approved',
            finalAmount,
            provider,
            resolvedAccountReference,
            payload.email,
            'Hourly while lessons are active'
          ]
        );

        return res.json({ message: 'Airtm payout submitted successfully.', provider, amount: finalAmount, airtm: airtmResponse.data });
      } catch (err) {
        console.error('Airtm payout error:', err.response?.data || err.message);
        return res.status(500).json({ message: 'Unable to create Airtm payout right now.' });
      }
    }

    // Default: PayPal flow
    const clientId = process.env.PAYPAL_CLIENT_ID;
    const clientSecret = process.env.PAYPAL_CLIENT_SECRET;

    if (!clientId || !clientSecret) {
      return res.status(503).json({
        message: 'Payout provider is not configured. Add PayPal credentials to enable real transfers.'
      });
    }

    const tokenResponse = await axios({
      method: 'post',
      url: `${process.env.PAYPAL_API_BASE || 'https://api-m.sandbox.paypal.com'}/v1/oauth2/token`,
      data: 'grant_type=client_credentials',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      auth: {
        username: clientId,
        password: clientSecret
      }
    });

    const accessToken = tokenResponse.data.access_token;

    const payoutResponse = await axios({
      method: 'post',
      url: `${process.env.PAYPAL_API_BASE || 'https://api-m.sandbox.paypal.com'}/v1/payments/payouts`,
      data: {
        sender_batch_header: {
          recipient_type: 'EMAIL',
            email_message: 'Your payout has been sent from Nivora.',
            note: 'Nivora payout',
          sender_batch_id: `novalearn-${Date.now()}`
        },
        items: [
          {
            recipient_type: 'EMAIL',
            amount: {
              value: String(finalAmount.toFixed(2)),
              currency: 'USD'
            },
            receiver: resolvedAccountReference,
            note: 'Nivora lesson payout',
            sender_item_id: `pay-${Date.now()}`
          }
        ]
      },
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      }
    });

    await run(
      'INSERT INTO ads (user_email, professor_name, course_title, specialty, bio, inspiration, payout_amount, payment_method, payment_account, payment_name, payout_schedule) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [
        payload.email,
        'Stored payout record',
        'Payout',
        provider,
        'Payout created through provider API',
        'Secure payout consent approved',
        finalAmount,
        provider,
        resolvedAccountReference,
        payload.email,
        'Hourly while lessons are active'
      ]
    );

    return res.json({
      message: 'Payout request submitted successfully.',
      provider,
      amount: finalAmount,
      paypal: payoutResponse.data
    });
  } catch (error) {
    console.error('Payout error:', error.response?.data || error.message);
    return res.status(500).json({ message: 'Unable to create payout right now.' });
  }
});

router.get('/consents', async (req, res) => {
  const authToken = getAuthToken(req);
  if (!authToken) {
    return res.status(401).json({ message: 'Authorization is required.' });
  }

  try {
    const payload = verifyAccessToken(authToken);
    const rows = await all(
      'SELECT * FROM payout_consents WHERE user_email = ? ORDER BY created_at DESC',
      [payload.email]
    );
    return res.json({ consents: rows });
  } catch (error) {
    console.error('List consents error:', error);
    return res.status(401).json({ message: 'Invalid or expired authentication token.' });
  }
});

module.exports = router;
