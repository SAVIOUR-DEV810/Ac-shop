const express = require('express');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const { get, run, all } = require('../db');
const { signAccessToken } = require('../utils/jwt');
const { verifyAccessToken } = require('../utils/jwt');
const { sendVerificationLink } = require('../utils/email');
const { validatePostalCode } = require('../utils/geocoding');

const router = express.Router();

const authRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 40,
  standardHeaders: true,
  legacyHeaders: false
});

router.use(authRateLimiter);

const MAX_USERS = 10000;
const CEO_EMAIL = 'igbokwefranksaviour@gmail.com';
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function verificationUrl(req, token) {
  const isProduction = process.env.NODE_ENV === 'production';
  const baseUrl = isProduction && process.env.FRONTEND_URL
    ? process.env.FRONTEND_URL
    : `${req.protocol}://${req.get('host')}`;
  return `${baseUrl.replace(/\/$/, '')}/verify-email.html?token=${encodeURIComponent(token)}`;
}

async function createVerificationLink(req, email) {
  const token = crypto.randomBytes(32).toString('hex');
  await run('DELETE FROM email_verification_tokens WHERE email = ?', [email]);
  await run(
    'INSERT INTO email_verification_tokens (email, token_hash, expires_at) VALUES (?, ?, ?)',
    [email, hashToken(token), Date.now() + 30 * 60 * 1000]
  );
  return verificationUrl(req, token);
}

async function sendVerification(req, email) {
  const link = await createVerificationLink(req, email);
  return sendVerificationLink({ to: email, link });
}

router.post('/ceo-session', async (req, res) => {
  if (!process.env.CEO_ACCESS_TOKEN || req.body?.token !== process.env.CEO_ACCESS_TOKEN) {
    return res.status(401).json({ message: 'CEO access denied.' });
  }
  return res.json({ token: signAccessToken({ email: CEO_EMAIL, role: 'ceo' }), role: 'ceo' });
});

router.get('/me', async (req, res) => {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization is required.' });
  }

  try {
    const payload = verifyAccessToken(header.replace('Bearer ', '').trim());
    if (payload.role === 'ceo') {
      return res.json({ user: { email: CEO_EMAIL, first_name: 'Nivora', last_name: 'CEO', email_verified: 1, role: 'ceo' } });
    }
    const user = await get(
      'SELECT email, first_name, last_name, phone, country, postal_code, latitude, longitude, email_verified FROM users WHERE email = ?',
      [payload.email]
    );
    if (!user) return res.status(404).json({ message: 'Account not found.' });
    return res.json({ user });
  } catch (error) {
    return res.status(401).json({ message: 'Your session is invalid or expired.' });
  }
});

router.get('/stats', async (req, res) => {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Authorization is required.' });
  }

  try {
    const payload = verifyAccessToken(header.replace('Bearer ', '').trim());
    if (payload.role === 'ceo') {
      const [users, revenue, completions] = await Promise.all([
        get('SELECT COUNT(*) AS count FROM users WHERE email_verified = 1'),
        get("SELECT COALESCE(SUM(total_amount), 0) AS total FROM enrollments WHERE status IN ('paid', 'completed', 'approved')"),
        get("SELECT COUNT(*) AS total, COALESCE(SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END), 0) AS completed FROM enrollments")
      ]);
      const totalEnrollments = Number(completions.total || 0);
      return res.json({ subscribers: Number(users.count || 0), revenue: Number(revenue.total || 0), completionRate: totalEnrollments ? Math.round((Number(completions.completed || 0) / totalEnrollments) * 100) : 0, enrollmentCount: totalEnrollments });
    }
    const user = await get('SELECT email_verified FROM users WHERE email = ?', [payload.email]);
    if (!user || !user.email_verified) {
      return res.status(403).json({ message: 'Verify your account to view live stats.' });
    }

    const [users, revenue, completions] = await Promise.all([
      get('SELECT COUNT(*) AS count FROM users WHERE email_verified = 1'),
      get("SELECT COALESCE(SUM(total_amount), 0) AS total FROM enrollments WHERE status IN ('paid', 'completed', 'approved')"),
      get("SELECT COUNT(*) AS total, COALESCE(SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END), 0) AS completed FROM enrollments")
    ]);

    const totalEnrollments = Number(completions.total || 0);
    return res.json({
      subscribers: Number(users.count || 0),
      revenue: Number(revenue.total || 0),
      completionRate: totalEnrollments ? Math.round((Number(completions.completed || 0) / totalEnrollments) * 100) : 0,
      enrollmentCount: totalEnrollments
    });
  } catch (error) {
    return res.status(401).json({ message: 'Your session is invalid or expired.' });
  }
});

router.post('/signup', async (req, res) => {
  const {
    email,
    password,
    firstName,
    lastName,
    phone,
    country,
    postalCode,
    latitude,
    longitude,
    verificationMethod = 'email'
  } = req.body || {};
  const normalizedEmail = String(email || '').trim().toLowerCase();

  if (!EMAIL_PATTERN.test(normalizedEmail) || String(password || '').length < 8) {
    return res.status(400).json({ message: 'A valid email and password (8+ chars) are required.' });
  }

  if (!String(firstName || '').trim() || !String(lastName || '').trim() || !String(country || '').trim() || !String(postalCode || '').trim()) {
    return res.status(400).json({ message: 'First name, surname, country, and postal code are required.' });
  }

  if (verificationMethod !== 'email') {
    return res.status(503).json({ message: 'SMS verification is not configured yet. Choose email verification.' });
  }

  try {
    const existing = await get('SELECT id FROM users WHERE email = ?', [normalizedEmail]);
    if (existing) {
      return res.status(409).json({ message: 'This email already has an account. Please log in.' });
    }

    const userCount = await get('SELECT COUNT(*) AS count FROM users');
    if (Number(userCount.count) >= MAX_USERS) {
      return res.status(409).json({ message: 'Nivora has reached its 10,000-account limit.' });
    }

    const addressCheck = await validatePostalCode({ country, postalCode, latitude, longitude });
    if (addressCheck.unavailable) {
      return res.status(503).json({ message: 'Address verification is temporarily unavailable. Please try again.' });
    }
    if (!addressCheck.valid) {
      return res.status(400).json({ message: 'We could not verify that postal code and location.' });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    await run(`
      INSERT INTO users (email, password_hash, first_name, last_name, phone, country, postal_code, latitude, longitude, email_verified)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
    `, [
      normalizedEmail,
      passwordHash,
      String(firstName).trim(),
      String(lastName).trim(),
      String(phone || '').trim(),
      String(country).trim(),
      String(postalCode).trim(),
      Number.isFinite(Number(latitude)) ? Number(latitude) : null,
      Number.isFinite(Number(longitude)) ? Number(longitude) : null
    ]);

    const emailResult = await sendVerification(req, normalizedEmail);

    if (!emailResult.ok) {
      await run('DELETE FROM email_verification_tokens WHERE email = ?', [normalizedEmail]);
      await run('DELETE FROM users WHERE email = ?', [normalizedEmail]);
      return res.status(503).json({ message: 'We could not send the verification link. Please try again.' });
    }

    return res.status(201).json({
      message: 'Account created. Open the verification link sent to your email.',
      email: normalizedEmail
    });
  } catch (error) {
    console.error('Signup error:', error);
    return res.status(500).json({ message: 'Unable to complete signup.' });
  }
});

router.get('/verify-email', async (req, res) => {
  const token = String(req.query.token || '');
  if (!token) {
    return res.status(400).json({ message: 'Verification link is missing.' });
  }

  try {
    const record = await get(
      'SELECT email FROM email_verification_tokens WHERE token_hash = ? AND expires_at >= ?',
      [hashToken(token), Date.now()]
    );
    if (!record) {
      return res.status(410).json({ message: 'This verification link is invalid or expired.' });
    }

    await run('UPDATE users SET email_verified = 1 WHERE email = ?', [record.email]);
    await run('DELETE FROM email_verification_tokens WHERE token_hash = ?', [hashToken(token)]);
    const accessToken = signAccessToken({ email: record.email });
    return res.json({ message: 'Account verified successfully.', token: accessToken });
  } catch (error) {
    console.error('Email verification error:', error);
    return res.status(500).json({ message: 'Unable to verify account.' });
  }
});

router.post('/verify-otp', async (req, res) => {
  const { email, otp } = req.body || {};

  if (!email || !otp) {
    return res.status(400).json({ message: 'Email and OTP are required.' });
  }

  try {
    const record = await get(
      'SELECT code, expires_at FROM otps WHERE email = ? ORDER BY created_at DESC LIMIT 1',
      [String(email).toLowerCase()]
    );

    if (!record) {
      return res.status(400).json({ message: 'No OTP found for this email.' });
    }

    if (Number(record.expires_at) < Date.now()) {
      return res.status(410).json({ message: 'OTP expired. Please request a new one.' });
    }

    if (record.code !== String(otp)) {
      return res.status(401).json({ message: 'Incorrect OTP.' });
    }

    await run('UPDATE users SET email_verified = 1 WHERE email = ?', [String(email).toLowerCase()]);
    await run('DELETE FROM otps WHERE email = ?', [String(email).toLowerCase()]);

    const token = signAccessToken({ email: String(email).toLowerCase() });
    return res.json({ message: 'Email verified successfully.', token });
  } catch (error) {
    console.error('OTP verification error:', error);
    return res.status(500).json({ message: 'Unable to verify OTP.' });
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body || {};

  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required.' });
  }

  try {
    const user = await get('SELECT * FROM users WHERE email = ?', [String(email).toLowerCase()]);
    if (!user) {
      return res.status(401).json({ message: 'Incorrect email or password.' });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password_hash);
    if (!isPasswordValid) {
      const failedAttempts = Number(user.failed_login_attempts || 0) + 1;
      const lockoutUntil = failedAttempts >= 5 ? Date.now() + 10 * 60 * 1000 : 0;

      await run(
        'UPDATE users SET failed_login_attempts = ?, lockout_until = ? WHERE email = ?',
        [failedAttempts, lockoutUntil, String(email).toLowerCase()]
      );

      if (failedAttempts >= 5) {
        return res.status(423).json({ message: 'Too many failed attempts. Account locked for 10 minutes.' });
      }

      return res.status(401).json({
        message: `Incorrect email or password. ${5 - failedAttempts} attempts remaining before lockout.`
      });
    }

    if (Date.now() < Number(user.lockout_until || 0)) {
      return res.status(423).json({ message: 'Account is temporarily locked. Please try again later.' });
    }

    await run('UPDATE users SET failed_login_attempts = 0, lockout_until = 0 WHERE email = ?', [String(email).toLowerCase()]);

    const token = signAccessToken({ email: String(email).toLowerCase() });
    return res.json({
      message: user.email_verified ? 'Login successful.' : 'Login successful. You can use David while your account remains unverified.',
      token,
      emailVerified: Boolean(user.email_verified)
    });
  } catch (error) {
    console.error('Login error:', error);
    return res.status(500).json({ message: 'Unable to log in.' });
  }
});

router.get('/users', async (req, res) => {
  try {
    const rows = await all('SELECT id, email, email_verified, created_at FROM users ORDER BY created_at DESC');
    return res.json({ users: rows });
  } catch (error) {
    console.error('Fetch users error:', error);
    return res.status(500).json({ message: 'Unable to load users.' });
  }
});

module.exports = router;
