const express = require('express');
const crypto = require('crypto');
const { get, run } = require('../db');
const { verifyAccessToken } = require('../utils/jwt');

const router = express.Router();

function getAuthToken(req) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return null;
  return header.replace('Bearer ', '').trim();
}

function getUserEmail(req) {
  const token = getAuthToken(req);
  if (!token) return null;
  try {
    return verifyAccessToken(token).email;
  } catch (error) {
    return null;
  }
}

function createCallCode() {
  return crypto.randomBytes(4).toString('hex').toUpperCase();
}

router.post('/', async (req, res) => {
  const hostEmail = getUserEmail(req);
  if (!hostEmail) {
    return res.status(401).json({ message: 'Authorization is required.' });
  }

  try {
    let callCode = createCallCode();
    while (await get('SELECT id FROM calls WHERE call_code = ?', [callCode])) {
      callCode = createCallCode();
    }

    const roomName = `NovaLearn-${callCode}`;
    const expiresAt = new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString();
    await run(
      'INSERT INTO calls (call_code, room_name, host_email, expires_at) VALUES (?, ?, ?, ?)',
      [callCode, roomName, hostEmail, expiresAt]
    );

    return res.status(201).json({
      message: 'Live call created.',
      call: {
        code: callCode,
        roomName,
        joinUrl: `https://meet.jit.si/${roomName}`,
        expiresAt
      }
    });
  } catch (error) {
    console.error('Create call error:', error);
    return res.status(500).json({ message: 'Unable to create live call.' });
  }
});

router.get('/:code', async (req, res) => {
  const callCode = String(req.params.code || '').trim().toUpperCase();
  if (!/^[A-F0-9]{8}$/.test(callCode)) {
    return res.status(400).json({ message: 'Enter a valid 8-character call code.' });
  }

  try {
    const call = await get(
      'SELECT call_code, room_name, expires_at FROM calls WHERE call_code = ?',
      [callCode]
    );
    if (!call || new Date(call.expires_at).getTime() < Date.now()) {
      return res.status(404).json({ message: 'That call code is invalid or expired.' });
    }

    return res.json({
      call: {
        code: call.call_code,
        roomName: call.room_name,
        joinUrl: `https://meet.jit.si/${call.room_name}`,
        expiresAt: call.expires_at
      }
    });
  } catch (error) {
    console.error('Join call lookup error:', error);
    return res.status(500).json({ message: 'Unable to find that live call.' });
  }
});

module.exports = router;