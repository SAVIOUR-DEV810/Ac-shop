const express = require('express');
const axios = require('axios');
const { run } = require('../db');
const { verifyAccessToken } = require('../utils/jwt');

const router = express.Router();

function getLearnerEmail(req) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return null;
  try {
    return verifyAccessToken(header.replace('Bearer ', '').trim()).email;
  } catch (error) {
    return null;
  }
}

router.post('/', async (req, res) => {
  const {
    learnerName,
    professorEmail,
    courseTitle,
    hours,
    hourlyRate,
    paymentMethod,
    paymentReference
  } = req.body || {};
  const normalizedHours = Number(hours);
  const normalizedRate = Number(hourlyRate);
  const platformFee = 5;

  if (!learnerName || !professorEmail || !courseTitle || !paymentMethod || !paymentReference) {
    return res.status(400).json({ message: 'Learner, professor, course, and payment details are required.' });
  }

  if (!Number.isInteger(normalizedHours) || normalizedHours < 1 || normalizedHours > 24) {
    return res.status(400).json({ message: 'Class duration must be between 1 and 24 hours.' });
  }

  if (!Number.isFinite(normalizedRate) || normalizedRate < 15) {
    return res.status(400).json({ message: 'Professor hourly rate must be at least $15.' });
  }

  if (/\d{12,}/.test(String(paymentReference).replace(/\s/g, ''))) {
    return res.status(400).json({ message: 'Do not enter a full card number. Use the last 4 digits or a wallet account.' });
  }

  const totalAmount = Number((normalizedHours * (normalizedRate + platformFee)).toFixed(2));
  const learnerEmail = getLearnerEmail(req);
  const provider = String(paymentMethod).toLowerCase();

  try {
    let providerOrderId = null;
    let approvalUrl = null;

    if (provider === 'paypal') {
      const clientId = process.env.PAYPAL_CLIENT_ID;
      const clientSecret = process.env.PAYPAL_CLIENT_SECRET;
      if (!clientId || !clientSecret) {
        return res.status(503).json({ message: 'PayPal billing is not configured yet. Add PayPal API credentials before charging learners.' });
      }

      const tokenResponse = await axios({
        method: 'post',
        url: `${process.env.PAYPAL_API_BASE || 'https://api-m.sandbox.paypal.com'}/v1/oauth2/token`,
        data: 'grant_type=client_credentials',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        auth: { username: clientId, password: clientSecret }
      });

      const orderResponse = await axios({
        method: 'post',
        url: `${process.env.PAYPAL_API_BASE || 'https://api-m.sandbox.paypal.com'}/v2/checkout/orders`,
        data: {
          intent: 'CAPTURE',
          purchase_units: [{
            description: `${courseTitle} enrollment (${normalizedHours} hour${normalizedHours === 1 ? '' : 's'})`,
            amount: { currency_code: 'USD', value: totalAmount.toFixed(2) }
          }],
          application_context: { user_action: 'PAY_NOW' }
        },
        headers: {
          Authorization: `Bearer ${tokenResponse.data.access_token}`,
          'Content-Type': 'application/json'
        }
      });

      providerOrderId = orderResponse.data.id;
      approvalUrl = orderResponse.data.links?.find(link => link.rel === 'approve')?.href || null;
    } else {
      return res.status(503).json({ message: 'This payment method is not connected to a billing provider yet. PayPal checkout is currently supported.' });
    }

    await run(
      `INSERT INTO enrollments (learner_email, learner_name, professor_email, course_title, hours, hourly_rate, platform_fee, total_amount, payment_method, payment_reference, status, provider_order_id)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [learnerEmail, String(learnerName), String(professorEmail), String(courseTitle), normalizedHours, normalizedRate, platformFee, totalAmount, provider, String(paymentReference), 'payment_pending', providerOrderId]
    );

    return res.status(201).json({
      message: 'Total calculated. Complete payment to finish enrollment.',
      amount: totalAmount,
      currency: 'USD',
      providerOrderId,
      approvalUrl
    });
  } catch (error) {
    console.error('Enrollment billing error:', error.response?.data || error.message);
    return res.status(502).json({ message: 'The payment provider could not create the bill.' });
  }
});

module.exports = router;