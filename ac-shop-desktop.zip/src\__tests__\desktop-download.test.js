const request = require('supertest');
const app = require('../../server');

describe('Desktop app download', () => {
  test('serves the Nivora desktop download as an attachment', async () => {
    const res = await request(app).get('/download/nivora-desktop.zip');

    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toMatch(/zip|application\/octet-stream|application\/zip/);
    expect(res.headers['content-disposition']).toMatch(/attachment/i);
    expect(res.headers['content-disposition']).toMatch(/nivora-desktop/i);
  });
});
