const express = require('express');
const { run, all, get } = require('../db');
const { verifyAccessToken } = require('../utils/jwt');

const router = express.Router();

function getAuthToken(req) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return null;
  return header.replace('Bearer ', '').trim();
}

async function requireVerifiedUser(req, res, next) {
  const token = getAuthToken(req);
  if (!token) return res.status(401).json({ message: 'Verify your account to access members and ads.' });

  try {
    const payload = verifyAccessToken(token);
    if (payload.role === 'ceo') {
      req.user = payload;
      return next();
    }
    const user = await get('SELECT email_verified FROM users WHERE email = ?', [payload.email]);
    if (!user || !user.email_verified) {
      return res.status(403).json({ message: 'Verify your account to access members and ads.' });
    }
    req.user = payload;
    return next();
  } catch (error) {
    return res.status(401).json({ message: 'Your session is invalid or expired.' });
  }
}

router.get('/', requireVerifiedUser, async (req, res) => {
  try {
    const rows = await all(
      `SELECT * FROM ads WHERE is_active = 1 ORDER BY created_at DESC`
    );
    return res.json({ ads: rows.map(ad => ({
      ...ad,
      email: ad.email || ad.user_email,
      professorName: ad.professor_name,
      courseTitle: ad.course_title,
      payoutAmount: Number(ad.payout_amount || 0),
      paymentMethod: ad.payment_method,
      paymentAccount: ad.payment_account,
      paymentName: ad.payment_name,
      payoutSchedule: ad.payout_schedule
    })) });
  } catch (error) {
    console.error('List ads error:', error);
    return res.status(500).json({ message: 'Unable to load ads.' });
  }
});

router.get('/:id', requireVerifiedUser, async (req, res) => {
  try {
    const ad = await get('SELECT * FROM ads WHERE id = ? AND is_active = 1', [req.params.id]);
    if (!ad) {
      return res.status(404).json({ message: 'Ad not found.' });
    }

    return res.json({
      ad: {
        ...ad,
        email: ad.email || ad.user_email,
        professorName: ad.professor_name,
        courseTitle: ad.course_title,
        payoutAmount: Number(ad.payout_amount || 0),
        paymentMethod: ad.payment_method,
        paymentAccount: ad.payment_account,
        paymentName: ad.payment_name,
        payoutSchedule: ad.payout_schedule
      }
    });
  } catch (error) {
    console.error('Get ad error:', error);
    return res.status(500).json({ message: 'Unable to load ad.' });
  }
});

router.delete('/:id', async (req, res) => {
  const token = getAuthToken(req);
  if (!token) {
    return res.status(401).json({ message: 'Authorization is required.' });
  }

  try {
    const payload = verifyAccessToken(token);
    const result = await run(
      'UPDATE ads SET is_active = 0 WHERE id = ? AND user_email = ? AND is_active = 1',
      [req.params.id, payload.email]
    );

    if (!result.changes) {
      return res.status(404).json({ message: 'Your active ad was not found.' });
    }

    return res.json({ message: 'Ad deleted successfully.' });
  } catch (error) {
    console.error('Delete ad error:', error);
    return res.status(401).json({ message: 'Invalid or expired authentication token.' });
  }
});

router.post('/', async (req, res) => {
  const token = getAuthToken(req);
  if (!token) {
    return res.status(401).json({ message: 'Authorization is required.' });
  }

  try {
    const payload = verifyAccessToken(token);
    const ad = req.body || {};

    if (!ad.professorName || !ad.courseTitle || !ad.specialty || !ad.email || !ad.bio || !ad.inspiration) {
      return res.status(400).json({ message: 'Missing required ad fields.' });
    }

    const consent = await get(
      'SELECT * FROM payout_consents WHERE user_email = ? AND consent_granted = 1 ORDER BY created_at DESC LIMIT 1',
      [payload.email]
    );

    if (!consent) {
      return res.status(403).json({ message: 'You must grant payout permission before creating an ad.' });
    }

    const payoutAmount = Number(ad.payoutAmount || 0);
    if (Number.isNaN(payoutAmount) || payoutAmount < 15) {
      return res.status(400).json({ message: 'Minimum payout must be at least $15.' });
    }

    const inserted = await run(
      `INSERT INTO ads (
        user_email, email, professor_name, course_title, specialty, bio, inspiration,
        payout_amount, payment_method, payment_account, payment_name, payout_schedule
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        payload.email,
        String(ad.email || payload.email),
        String(ad.professorName),
        String(ad.courseTitle),
        String(ad.specialty),
        String(ad.bio),
        String(ad.inspiration),
        payoutAmount,
        String(ad.paymentMethod || 'visa'),
        String(ad.paymentAccount || ''),
        String(ad.paymentName || payload.email),
        String(ad.payoutSchedule || 'Hourly while lessons are active')
      ]
    );

    return res.status(201).json({
      message: 'Ad created successfully.',
      ad: {
        id: inserted.id,
        user_email: payload.email,
        email: String(ad.email || payload.email),
        professor_name: String(ad.professorName),
        course_title: String(ad.courseTitle),
        specialty: String(ad.specialty),
        bio: String(ad.bio),
        inspiration: String(ad.inspiration),
        payout_amount: payoutAmount,
        payment_method: String(ad.paymentMethod || 'visa'),
        payment_account: String(ad.paymentAccount || ''),
        payment_name: String(ad.paymentName || payload.email),
        payout_schedule: String(ad.payoutSchedule || 'Hourly while lessons are active'),
        is_active: 1
      }
    });
  } catch (error) {
    console.error('Create ad error:', error);
    return res.status(401).json({ message: 'Invalid or expired authentication token.' });
  }
});

module.exports = router;
