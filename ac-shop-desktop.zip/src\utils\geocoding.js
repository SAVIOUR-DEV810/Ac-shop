const axios = require('axios');

async function validatePostalCode({ country, postalCode, latitude, longitude }) {
  const apiKey = process.env.OPENCAGE_API_KEY;
  if (!apiKey) {
    return { configured: false, valid: true };
  }

  try {
    const response = await axios.get(process.env.OPENCAGE_API_BASE || 'https://api.opencagedata.com/geocode/v1/json', {
      params: {
        key: apiKey,
        q: `${postalCode}, ${country}`,
        limit: 5,
        no_annotations: 1
      },
      timeout: 8000
    });

    const results = response.data?.results || [];
    if (!results.length) return { configured: true, valid: false };

    const nearest = results[0].geometry || {};
    const hasCoordinates = Number.isFinite(Number(latitude)) && Number.isFinite(Number(longitude));
    const distance = hasCoordinates
      ? Math.hypot(Number(nearest.lat) - Number(latitude), Number(nearest.lng) - Number(longitude))
      : 0;

    return { configured: true, valid: distance === 0 || distance < 1.5 };
  } catch (error) {
    console.error('Geocoding validation error:', error.response?.data || error.message);
    return { configured: true, valid: false, unavailable: true };
  }
}

module.exports = { validatePostalCode };
